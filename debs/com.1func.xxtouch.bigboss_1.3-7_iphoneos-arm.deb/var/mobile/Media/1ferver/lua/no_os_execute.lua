--[[

	no_os_execute.lua

	Created by 苏泽 on 22-11-06.
	Copyright (c) 2022年 苏泽. All rights reserved.

	local noexecute = require('no_os_execute')

	errlist = noexecute.cp_r('/var/mobile/Media/1ferver/web', '/var/mobile/Media/1ferver/web2')
	noexecute.lchmod_r('/var/mobile/Media/1ferver/web2', 644)
	noexecute.lchown_r('/var/mobile/Media/1ferver/web2', 501, 501)
	noexecute.lchownmod_r('/var/mobile/Media/1ferver/web2', 501, 501, 755)
	noexecute.rm_rf('/var/mobile/Media/1ferver/web2')
	noexecute.killall(9, 'XXTExplorer')

--]]

local _ENV = table.deep_copy(_ENV)

local _M = {}

local lfs = require 'lfs'
local P = require 'path'
local _debug_getinfo = debug.getinfo
local ok, unix = pcall(require, 'unix')
if not ok then
	unix = {
		kill = sys.kill,
		lchown = sys.lchown,
		lchmod = sys.lchmod,
	}
end
unix.lchmod = unix.lchmod or sys.lchmod or unix.chmod
local ok, stdlib = pcall(require, 'posix.stdlib')
if ok then
	sys.realpath = sys.realpath or stdlib.realpath
end
local _lfs_dir = lfs.dir
local _lfs_attributes = lfs.attributes
local _lfs_mkdir = lfs.mkdir
local _io_open = io.open
local _string_format = string.format
functor = type(functor) == 'table' and functor or {
	argth = {
		check_value = function(arg_count, expected_type, ...)
			local argc = select("#", ...)
			if argc<arg_count then
				local dbinfo = _debug_getinfo(2)
				local ftype = (type(dbinfo.namewhat)=="string" and dbinfo.namewhat) or ""
				local fname = (type(dbinfo.name)=="string" and dbinfo.name) or (type(field)=="string" and field) or "?"
				local got_type = (type(the_value)=="number" and math.type(the_value)) or type(the_value)
				error(_string_format("bad argument #%d%s to%s '%s' (%s expected%s)", arg_count, "", ftype, fname, expected_type, ", got no value"), 3)
			else
				local the_value = select(arg_count, ...)
				if expected_type=="integer" and tonumber(the_value) and math.tointeger(tonumber(the_value)) then
					return math.tointeger(tonumber(the_value))
				elseif expected_type=="number" and tonumber(the_value) then
					return tonumber(the_value)
				elseif string.find(expected_type, "integer") and tonumber(the_value) and math.tointeger(tonumber(the_value)) then
					return the_value
				elseif string.find(expected_type, "number") and tonumber(the_value) then
					return the_value
				elseif not string.find(expected_type, type(the_value)) then
					local dbinfo = _debug_getinfo(2)
					local ftype = (type(dbinfo.namewhat)=="string" and dbinfo.namewhat) or ""
					local fname = (type(dbinfo.name)=="string" and dbinfo.name) or (type(field)=="string" and field) or "?"
					local got_type = (type(the_value)=="number" and math.type(the_value)) or type(the_value)
					error(_string_format("bad argument #%d%s to%s '%s' (%s expected%s)", arg_count, "", ftype, fname, expected_type, _string_format(", got %s", got_type)), 3)
				else
					return the_value
				end
			end
		end,
	}
}
local _check_value = functor.argth.check_value

local function _directory_all_files(dir, list)
	list = list or {}
	for name in _lfs_dir(dir) do
		if (name ~= '.' and name ~= '..') then
			local item_path = dir..'/'..name
			local item = _lfs_attributes(item_path)
			list[#list + 1] = item_path
			if (item.mode == 'directory') then
				_directory_all_files(item_path, list)
			end
		end
	end
	list[#list + 1] = dir
	return list
end

local function _list_all_files(path)
	local list = {}
	local info = _lfs_attributes(path)
	if (type(info) == 'table' and info.mode == 'directory') then
		return _directory_all_files(path, list)
	else
		if (info ~= nil) then
			list[#list + 1] = path
		end
	end
	return list
end

local function _SM(s, o, g, p)
	return s*8^3 | o*8^2 | g*8 | p
end

local function _SM_D2O(dmode)
	if (dmode > 7777 or dmode < 0) then
		return nil, _string_format("mode value range 0000 ~ 7777, got %d", dmode)
	end
	local s = dmode - (dmode%1000)
	local o = dmode - s
	o = o - o%100
	local g = dmode - s - o
	g = g - g%10
	local p = dmode % 10
	local math_floor = math.floor
	s = math_floor(s / 1000)
	o = math_floor(o / 100)
	g = math_floor(g / 10)
	if (s > 7 or o > 7 or g > 7 or p > 7) then
		return nil, _string_format("mode value range 0000 ~ 7777, field range 0 ~ 7, got %d%d%d%d", s, o, g, p)
	end
	return _SM(s, o, g, p)
end

function _M.lchmod_r(...) -- (path, dmode)
	local path = _check_value(1, 'string', ...)
	local dmode = _check_value(2, 'integer', ...)
	local sys_lchmod = unix.lchmod
	local mode, err = _SM_D2O(dmode)
	if not mode then
		error("bad argument #2 to '"..tostring(_debug_getinfo(1).name or "?").."' (" .. err .. ")", 2)
	end
	for _,v in ipairs(_list_all_files(path)) do
		sys_lchmod(v, mode)
	end
end

function _M.lchown_r(...) -- (path, uid, gid)
	local path = _check_value(1, 'string', ...)
	local uid = _check_value(2, 'integer', ...)
	local gid = _check_value(3, 'integer', ...)
	local sys_lchown = unix.lchown
	for _,v in ipairs(_list_all_files(path)) do
		sys_lchown(v, uid, gid)
	end
end

function _M.lchownmod_r(...) -- (path, uid, gid, dmode)
	local path = _check_value(1, 'string', ...)
	local uid = _check_value(2, 'integer', ...)
	local gid = _check_value(3, 'integer', ...)
	local dmode = _check_value(4, 'integer', ...)
	local sys_lchown = unix.lchown
	local sys_lchmod = unix.lchmod
	local mode, err = _SM_D2O(dmode)
	if not mode then
		error("bad argument #4 to '"..tostring(_debug_getinfo(1).name or "?").."' (" .. err .. ")", 2)
	end
	for _,v in ipairs(_list_all_files(path)) do
		sys_lchown(v, uid, gid)
		sys_lchmod(v, mode)
	end
end

function _M.rm_rf(...) -- (path)
	local path = _check_value(1, 'string', ...)
	if (#path < 20) then
		error("bad argument #1 to '"..tostring(_debug_getinfo(1).name or "?").."' (too short)", 2)
	end
	local os_remove = os.remove
	for _,v in ipairs(_list_all_files(path)) do
		os_remove(v)
	end
end

local function _cp_file(src, dest)
	local sf, err = _io_open(src, 'r')
	if sf == nil then
		return nil, _string_format("%s %q", err, src)
	end
	local df, err = _io_open(dest, 'w')
	if df == nil then
		return nil, _string_format("%s %q", err, dest)
	end
	local buf
	repeat
		buf = sf:read(1024 * 1024 * 10)
		if (buf) then
			df:write(buf)
		end
	until not buf
	sf:close()
	df:close()
	return true
end

local function _cp_dir(src_dir, dest_dir, errlist)
	errlist = errlist or {}
	for name in _lfs_dir(src_dir) do
		if (name ~= '.' and name ~= '..') then
			local src_item_path = src_dir..'/'..name
			local src_item = _lfs_attributes(src_item_path)
			local dest_item_path = dest_dir..'/'..name
			local dest_item = _lfs_attributes(dest_item_path)
			if (src_item.mode == 'directory') then
				if dest_item == nil then
					_lfs_mkdir(dest_item_path)
					_cp_dir(src_item_path, dest_item_path, errlist)
				elseif (dest_item.mode == 'directory') then
					_cp_dir(src_item_path, dest_item_path, errlist)
				else
					errlist[#errlist + 1] = _string_format('cannot overwrite non-directory %q with directory %q', dest_item_path, src_item_path)
				end
			elseif (src_item.mode == 'file') then
				if (dest_item == nil or dest_item.mode == 'file') then
					local ok, err = _cp_file(src_item_path, dest_item_path)
					if not ok then
						errlist[#errlist + 1] = err
					end
				else
					errlist[#errlist + 1] = _string_format('cannot overwrite %s %q with file %q', dest_item.mode, dest_item_path, src_item_path)
				end
			end
		end
	end
	return errlist
end

function _M.cp_r(...)
	local src = _check_value(1, 'string', ...)
	local dest = _check_value(2, 'string', ...)
	local errlist = {}
	local src_real_path = sys.realpath(src)
	local src_parent_path
	local dest_real_path = sys.realpath(dest)
	if not src_real_path then
		errlist[#errlist + 1] = _string_format('No such file or directory %q', src)
		return errlist
	else
		src_parent_path = sys.realpath(P.join(src_real_path, '..'))
	end
	if not dest_real_path then
		local dirname, basename = P.splitpath(dest)
		dest_real_path = sys.realpath(dirname)
		if dest_real_path then
			dest_real_path = P.join(dest_real_path, basename)
		end
	end
	if not dest_real_path then
		errlist[#errlist + 1] = _string_format('cannot create directory %q: No such file or directory', dest)
		return errlist
	end
	if (src_real_path == dest_real_path) or (src_parent_path == dest_real_path) then
		errlist[#errlist + 1] = _string_format('%s == %s', src, dest)
		return errlist
	end
	if src_real_path == '/' then
		error('no!', 2)
	end
	src = P.remove_dir_end(src_real_path)
	dest = P.remove_dir_end(dest_real_path)
	local src_info, err = _lfs_attributes(src)
	local dest_info = _lfs_attributes(dest)
	if (src_info == nil) then
		errlist[#errlist + 1] = err
		return errlist
	end
	if (src_info.mode == 'directory') then
		if (dest_info == nil) then
			local ok, err = _lfs_mkdir(dest)
			if ok then
				_cp_dir(src, dest, errlist)
			else
				errlist[#errlist + 1] = _string_format('%s %q', err, dest)
				return errlist
			end
		elseif (dest_info.mode == 'directory') then
			dest = P.join(dest, P.basename(src))
			if (src == dest) then
				return errlist
			end
			local ok, err = _lfs_attributes(dest)
			if not ok then
				ok, err = _lfs_mkdir(dest)
			end
			if ok then
				_cp_dir(src, dest, errlist)
			else
				errlist[#errlist + 1] = _string_format('%s %q', err, dest)
				return errlist
			end
		else
			errlist[#errlist + 1] = _string_format('cannot overwrite non-directory %q with directory %q', dest, src)
			return errlist
		end
	elseif (src_info.mode == 'file') then
		if (dest_info == nil or dest_info.mode == 'file') then
			local ok, err = _cp_file(src, dest)
			if not ok then
				errlist[#errlist + 1] = err
			end
		elseif (dest_info.mode == 'directory') then
			dest = P.join(dest, P.basename(src))
			if (src == dest) then
				return errlist
			end
			local ok, err = _cp_file(src, dest)
			if not ok then
				errlist[#errlist + 1] = err
			end
		else
			errlist[#errlist + 1] = _string_format('cannot overwrite %s %q with file %q', dest_info.mode, dest, src)
		end
	end
	return errlist
end

function _killall(...)
	local sig = _check_value(1, 'integer', ...)
	local namelist = {select(2, ...)}
	local procs = app.all_procs()
	local sys_kill = unix.kill
	for _,info in ipairs(procs) do
		if (type(info) == 'table' and type(info.pid) == 'number') then
			for _,name in ipairs(namelist) do
				if (type(name) == 'string' and info.name == name) then
					sys_kill(info.pid, sig)
				end
			end
		end
	end
end
_M.killall = _killall

function _M.respring()
	_killall(9, 'SpringBoard', 'backboardd', 'cfprefsd')
end

--[[
nLog(_M.cp_r('/var/mobile/Media/1ferver/web', '/var/mobile/Media/1ferver/web2'))
_M.lchmod_r('/var/mobile/Media/1ferver/web2', 644)
_M.lchown_r('/var/mobile/Media/1ferver/web2', 501, 501)
_M.lchownmod_r('/var/mobile/Media/1ferver/web2', 501, 501, 755)
_M.rm_rf('/var/mobile/Media/1ferver/web2')
_M.killall(9, 'XXTExplorer')
--]]

return _M